#!/usr/bin/env bash
set -euo pipefail
if [ ! -f docker-compose.yml ]; then
  echo "Run this from the repository root."
  exit 1
fi
cp -n .env.example .env || true
docker compose build
docker compose up -d db redis
echo "Waiting for database…"
until docker compose exec -T db mysql -ularavel -plaravel -e "SELECT 1" >/dev/null 2>&1; do
  sleep 2
  printf "."
done
echo
docker compose up -d app web queue scheduler
docker compose exec -T app php artisan key:generate --force
docker compose exec -T app php artisan migrate --seed --force
docker compose exec -T app php artisan storage:link || true
echo "Visit http://localhost:8080"
echo "Login: admin@example.com / password (change it!)"
